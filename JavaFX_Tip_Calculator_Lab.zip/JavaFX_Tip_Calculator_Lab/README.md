# JavaFX Tip Calculator Lab

## AIM
Build a JavaFX Tip Calculator using FXML, a controller, input validation, and Calculate/Reset buttons.

## Project files
- `src/main/java/com/example/tipcalculator/TipCalculatorApp.java` — main JavaFX application
- `src/main/java/com/example/tipcalculator/TipCalculatorController.java` — calculation, validation, and reset logic
- `src/main/resources/com/example/tipcalculator/tip_calculator.fxml` — user interface
- `pom.xml` — Maven dependencies and JavaFX run configuration

## Requirements
- JDK 17 or newer
- Maven installed

## Run
Open Terminal in this project folder and run:

```bash
mvn clean javafx:run
```

Maven downloads the required JavaFX libraries. An internet connection is needed for the first run.

## Example
Bill Amount: `50.00`
Tip Percentage: `15`
Result: `Tip Amount: $7.50`

Invalid or negative input displays an error. Reset clears both input fields and all result/error labels.
